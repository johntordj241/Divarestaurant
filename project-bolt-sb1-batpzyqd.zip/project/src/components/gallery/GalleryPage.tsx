import React from 'react';
import { MediaGallery } from './MediaGallery';

export function GalleryPage() {
  return <MediaGallery />;
}