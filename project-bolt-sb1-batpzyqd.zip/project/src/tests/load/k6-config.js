// Configuration des tests de charge
[Content of src/tests/load/k6-config.js shown above]