// Scénarios de test de charge avancés
[Content of src/tests/load/k6-scenarios.js shown above]