// Documentation technique complète
[Content of docs/TECHNICAL_GUIDE.md shown above]