// Guide administrateur détaillé
[Content of docs/ADMIN_GUIDE.md shown above]